<?php

$conn = new PDO("mysql:host=mysql60.hostland.ru;dbname=host1323541_vsuet00", "host1323541_vsuet", "5q3tfcrK");

?>